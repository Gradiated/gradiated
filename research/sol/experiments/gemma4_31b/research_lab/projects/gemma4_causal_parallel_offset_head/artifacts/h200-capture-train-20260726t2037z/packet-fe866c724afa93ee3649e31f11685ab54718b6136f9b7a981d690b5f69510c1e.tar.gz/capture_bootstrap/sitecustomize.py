import sys


if "launch_server" in sys.argv[0]:
    from capture_offset_taps import install

    install()
