"""Bound request-local verified-trunk overlay for the resident NGRAM worker."""
from __future__ import annotations
import atexit, hashlib, json, os, threading, time
from pathlib import Path
import numpy as np

ROOT = Path(os.environ.get("REQUEST_LOCAL_ROOT", "/work"))
OUT = Path(os.environ.get("REQUEST_LOCAL_OUT", str(ROOT / "out")))
OUT.mkdir(parents=True, exist_ok=True)
TRACE = OUT / "request-local-ngram.jsonl"
LOCK = threading.Lock()

def atomic(name, row):
    p=OUT/name; q=p.with_suffix(p.suffix+".part"); q.write_text(json.dumps(row,sort_keys=True,indent=2)+"\n"); q.replace(p)
def emit(row):
    with LOCK:
        with TRACE.open("a") as f: f.write(json.dumps(row,sort_keys=True)+"\n")
def digest(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

from sglang.srt.speculative.ngram_worker import NGRAMWorker
from sglang.srt.speculative.cpp_ngram.ngram_corpus import NgramCorpus
ORIG_INIT=NGRAMWorker.__init__
ORIG_PREPARE=NGRAMWorker._prepare_draft_tokens
ORIG_UPDATE=NGRAMWorker._update_ngram_corpus
ORIG_FORWARD=NGRAMWorker.forward_batch_generation

def paths(tokens, mask, n):
    rows=np.asarray(mask).reshape(n,n)
    toks=np.asarray(tokens).reshape(n).tolist()
    leaves=[]
    sets=[set(np.flatnonzero(rows[i]).tolist()) for i in range(n)]
    for i,s in enumerate(sets):
        if s and not any(s < t for t in sets): leaves.append([toks[j] for j in sorted(s)])
    return leaves

def merge(local_toks, local_mask, global_toks, global_mask, n):
    """Reserve the longest local verified path, then append global BFS leaves."""
    lp=paths(local_toks,local_mask,n); gp=paths(global_toks,global_mask,n)
    trunk=max(lp,key=len,default=[])
    tree=[{}]; order=[]; ancestry=[]
    def add(seq):
        node=0; parent=[]
        for token in seq:
            nxt=tree[node].get(token)
            if nxt is None:
                if len(order)>=n: return
                nxt=len(tree); tree[node][token]=nxt; tree.append({}); order.append(token); ancestry.append(parent+[len(order)-1])
            node=nxt; parent=ancestry[nxt-1]
    add(trunk)
    for seq in gp: add(seq)
    # Native result always has n rows; retain native global filler if branches overlap.
    for seq in lp: add(seq)
    if len(order)<n:
        for token in np.asarray(global_toks).reshape(n).tolist(): add([token])
    if len(order)!=n: raise RuntimeError(f"request_local_tree_underfilled:{len(order)}")
    mask=np.zeros((n,n),dtype=np.uint8)
    for i,anc in enumerate(ancestry): mask[i,anc]=1
    return np.asarray(order,dtype=np.int32),mask.reshape(-1),len(trunk)

def patched_init(self,*a,**kw):
    ORIG_INIT(self,*a,**kw)
    self._request_local={}
    self._request_local_args={"min_bfs_breadth":a[0].speculative_ngram_min_bfs_breadth,"max_bfs_breadth":a[0].speculative_ngram_max_bfs_breadth,"match_type":a[0].speculative_ngram_match_type,"capacity":a[0].speculative_ngram_capacity,"max_trie_depth":a[0].speculative_ngram_max_trie_depth,"draft_token_num":a[0].speculative_num_draft_tokens,"external_sam_budget":0,"external_corpus_max_tokens":0}
    self._request_local_stats={"prepare_calls":0,"update_calls":0,"target_verify_forwards":0,"target_verify_rows":0,"local_trunk_lengths":{},"seen":set()}
    target=self.target_worker.forward_batch_generation
    def timed(*aa,**kk):
        result=target(*aa,**kk)
        if kk.get("is_verify",False):
            self._request_local_stats["target_verify_forwards"]+=1
            self._request_local_stats["target_verify_rows"]+=len(aa[0].reqs) * self.draft_token_num
        return result
    self.target_worker.forward_batch_generation=timed
    emit({"event":"worker_initialized","overlay_sha256":digest(__file__),"draft_token_num":self.draft_token_num,"max_depth":self.max_trie_depth})

def local_for(self,rid):
    c=self._request_local.get(rid)
    if c is None:
        a=self._request_local_args
        c=NgramCorpus(**a); self._request_local[rid]=c
    return c

def patched_prepare(self,batch):
    self.ngram_corpus.synchronize()
    ids=[]; tails=[]; lens=[]
    for req in batch.reqs:
        ids.append(req.rid); tails.append(self._efficient_concat_last_n(req.origin_input_ids,req.output_ids,self.max_trie_depth)); lens.append(len(req.origin_input_ids)+len(req.output_ids))
    gt,gm=self.ngram_corpus.batch_get(ids,tails,lens)
    n=self.draft_token_num; out_t=[]; out_m=[]; trunks={}
    for i,(rid,tail,total) in enumerate(zip(ids,tails,lens)):
        c=local_for(self,rid); c.synchronize(); lt,lm=c.batch_get([rid],[tail],[total])
        mt,mm,depth=merge(lt,lm,gt[i*n:(i+1)*n],gm[i*n*n:(i+1)*n*n],n)
        out_t.append(mt); out_m.append(mm); trunks[str(rid)]=depth
    s=self._request_local_stats; s["prepare_calls"]+=1; s["local_trunk_lengths"].update(trunks); s["seen"].update(map(str,ids))
    emit({"event":"prepare","requests":len(ids),"trunks":trunks,"target_verify_forwards":s["target_verify_forwards"],"target_verify_rows":s["target_verify_rows"]})
    return np.concatenate(out_t),np.concatenate(out_m)

def patched_update(self,batch):
    global_tokens=[]
    for req in batch.reqs:
        tokens=self._efficient_concat_last_n(req.origin_input_ids,req.output_ids,self.max_trie_depth)
        global_tokens.append(tokens)
        # This method runs only after NgramVerifyInput.verify: output_ids are target-verified.
        local_for(self,req.rid).batch_put([tokens])
    self.ngram_corpus.batch_put(global_tokens)
    self._request_local_stats["update_calls"]+=1

def patched_forward(self,*a,**kw):
    try: return ORIG_FORWARD(self,*a,**kw)
    finally:
        batch=a[0]
        for req in batch.reqs:
            if req.finished() or req.is_retracted: self._request_local.pop(req.rid,None)
        s=getattr(self,"_request_local_stats",None)
        if s: emit({"event":"forward","target_verify_forwards":s["target_verify_forwards"],"target_verify_rows":s["target_verify_rows"],"active_local_tries":len(self._request_local)})

def patched_erase(self, req_ids):
    for rid in req_ids: self._request_local.pop(rid,None)
    return self.ngram_corpus.erase_match_state(req_ids)

# Preserve original cleanup call by wrapping corpus cleanup after every forward.
NGRAMWorker.__init__=patched_init
NGRAMWorker._prepare_draft_tokens=patched_prepare
NGRAMWorker._update_ngram_corpus=patched_update
NGRAMWorker.forward_batch_generation=patched_forward
atomic("OVERLAY_STATE.json",{"overlay":"request_local_verified_trunk","overlay_sha256":digest(__file__),"source":"target_verified_tokens_only","global_fallback":"unchanged_BFS_recency","depth":12})
