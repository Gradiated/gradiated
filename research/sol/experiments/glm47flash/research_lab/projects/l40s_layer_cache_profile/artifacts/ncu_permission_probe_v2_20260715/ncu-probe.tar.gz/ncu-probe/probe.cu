#include <cuda_runtime.h>
#include <cstdio>
__global__ void saxpy(float *x) { int i=blockIdx.x*blockDim.x+threadIdx.x; if(i<1048576) x[i]=x[i]*1.0001f+1.f; }
int main(){ float *x; cudaMalloc(&x,1048576*sizeof(float)); for(int i=0;i<20;i++) saxpy<<<4096,256>>>(x); auto e=cudaDeviceSynchronize(); printf("cudaDeviceSynchronize=%s\n",cudaGetErrorString(e)); cudaFree(x); return e!=cudaSuccess; }
